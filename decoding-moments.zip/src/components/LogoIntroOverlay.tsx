import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, ArrowDown, Sparkles } from 'lucide-react';
import { HandDrawnLogoSvg } from './HandDrawnLogoSvg';

interface LogoIntroOverlayProps {
  onComplete: () => void;
  isOpen: boolean;
}

export const LogoIntroOverlay: React.FC<LogoIntroOverlayProps> = ({ onComplete, isOpen }) => {
  const [isDrawn, setIsDrawn] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    // The logo stroke animation completes at ~5.35s
    const drawnTimer = setTimeout(() => {
      setIsDrawn(true);
    }, 5350);

    // If untouched, automatically trigger the curtain reveal after a luxurious 2.2s showcase
    const autoExitTimer = setTimeout(() => {
      handleTriggerExit();
    }, 7600);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter' || e.code === 'Escape' || e.code === 'ArrowDown') {
        handleTriggerExit();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearTimeout(drawnTimer);
      clearTimeout(autoExitTimer);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleTriggerExit = () => {
    if (isExiting) return;
    setIsExiting(true);
    // Curtain parting duration is 1.1s
    setTimeout(() => {
      onComplete();
    }, 1100);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        id="logo-intro-stage"
        className="fixed inset-0 z-50 overflow-hidden select-none"
        onClick={handleTriggerExit}
      >
        {/* CSS Animation Keyframes for Stroke Mask Drawing & Gold Specular Effects */}
        <style dangerouslySetInnerHTML={{ __html: `
          .intro-anim-path {
            fill: none;
            stroke-linecap: round;
            stroke-linejoin: round;
            stroke-dasharray: 1;
            stroke-dashoffset: 1;
            pathLength: 1;
            animation: introRevealPath var(--d) linear var(--delay) forwards;
          }

          @keyframes introRevealPath {
            to { stroke-dashoffset: 0; }
          }

          mask .intro-anim-path {
            stroke: white;
          }

          #introDmMonogram {
            mask: url(#intro_mask_dm);
            -webkit-mask: url(#intro_mask_dm);
          }
          #introSuitcaseGroup {
            mask: url(#intro_mask_suitcase);
            -webkit-mask: url(#intro_mask_suitcase);
          }
          #introDecodingGroup {
            mask: url(#intro_mask_decoding);
            -webkit-mask: url(#intro_mask_decoding);
          }
          #introMomentsGroup {
            mask: url(#intro_mask_moments);
            -webkit-mask: url(#intro_mask_moments);
          }
          #introLinesGroup {
            mask: url(#intro_mask_lines);
            -webkit-mask: url(#intro_mask_lines);
          }

          @keyframes goldGlintSweep {
            0% { transform: translateX(-100%) rotate(25deg); opacity: 0; }
            40% { opacity: 0.7; }
            100% { transform: translateX(200%) rotate(25deg); opacity: 0; }
          }

          .gold-glint-effect {
            animation: goldGlintSweep 1.6s cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
          }
        ` }} />

        {/* =========================================================================
            TOP THEATER CURTAIN (Slides UP to -100% on exit)
           ========================================================================= */}
        <motion.div
          id="curtain-top-panel"
          initial={{ y: '0%' }}
          animate={{ y: isExiting ? '-100%' : '0%' }}
          transition={{ duration: 1.1, ease: [0.77, 0, 0.175, 1] }}
          className="absolute top-0 left-0 right-0 h-1/2 bg-[#050504] z-20 overflow-hidden"
        >
          {/* Ambient Warm Golden Depth */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_100%,rgba(210,164,74,0.14),transparent_60%)]" />
          
          {/* Golden Hem Seam: ONLY visible during exit separation */}
          {isExiting && (
            <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#F0C45B] to-transparent shadow-[0_0_20px_rgba(240,196,91,0.8)] opacity-80" />
          )}
        </motion.div>

        {/* =========================================================================
            BOTTOM THEATER CURTAIN (Slides DOWN to +100% on exit)
           ========================================================================= */}
        <motion.div
          id="curtain-bottom-panel"
          initial={{ y: '0%' }}
          animate={{ y: isExiting ? '100%' : '0%' }}
          transition={{ duration: 1.1, ease: [0.77, 0, 0.175, 1] }}
          className="absolute bottom-0 left-0 right-0 h-1/2 bg-[#050504] z-20 overflow-hidden"
        >
          {/* Ambient Warm Golden Depth */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(210,164,74,0.14),transparent_60%)]" />
          
          {/* Golden Hem Seam: ONLY visible during exit separation */}
          {isExiting && (
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#F0C45B] to-transparent shadow-[0_0_20px_rgba(240,196,91,0.8)] opacity-80" />
          )}
        </motion.div>

        {/* =========================================================================
            THE HORIZON LASER BEAM (Flares only when curtains actually part on exit)
           ========================================================================= */}
        {isExiting && (
          <motion.div
            id="curtain-horizon-beam"
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{
              scaleX: [0, 1.2, 0.8],
              opacity: [1, 0.9, 0],
            }}
            transition={{ duration: 0.9, ease: 'easeOut' }}
            className="absolute top-1/2 left-0 right-0 -translate-y-1/2 h-[3px] bg-gradient-to-r from-transparent via-[#FFF6DE] via-[#F0C45B] to-transparent z-40 pointer-events-none shadow-[0_0_35px_rgba(240,196,91,0.9)]"
          />
        )}

        {/* =========================================================================
            CENTRAL STAGE: LOGO + INTERACTIVE GOLDEN LINE & ARROW PROMPT
           ========================================================================= */}
        <motion.div
          id="intro-center-stage"
          initial={{ opacity: 1 }}
          animate={{
            opacity: isExiting ? 0 : 1,
            scale: isExiting ? 1.06 : 1,
            filter: isExiting ? 'blur(8px)' : 'blur(0px)',
          }}
          transition={{ duration: 0.55, ease: 'easeOut' }}
          className="relative z-30 flex flex-col items-center justify-center w-full h-full cursor-pointer px-4"
        >
          {/* Skip Action Indicator (Top Right) */}
          <div
            id="intro-skip-pill"
            className="absolute top-6 right-6 sm:top-8 sm:right-8 z-30 flex items-center space-x-2 px-4 py-2 rounded-full border border-[#D49A25]/30 text-[10px] tracking-[0.25em] uppercase text-[#C2B295] hover:text-[#FAF6F0] hover:border-[#D49A25] transition-all bg-[#080807]/80 backdrop-blur-md shadow-lg"
          >
            <span>Click to Enter</span>
            <span className="text-[#D49A25]">↓</span>
          </div>

          {/* Logo Container */}
          <div className="relative w-[min(76vw,660px)] aspect-square flex-shrink-0 flex items-center justify-center p-2 sm:p-4 overflow-hidden">
            {/* Shimmer Glint Sweep after drawing finishes */}
            {isDrawn && !isExiting && (
              <div
                className="gold-glint-effect absolute inset-0 w-1/3 bg-gradient-to-r from-transparent via-[#FFF8E7]/30 to-transparent pointer-events-none z-20"
              />
            )}

            {/* Hand-Drawn Vector SVG (Exact Geometry & Masks) */}
            <HandDrawnLogoSvg />
          </div>

          {/* =====================================================================
              AFTER DRAWING COMPLETES: GLOWING VERTICAL LINE, ARROW & ENTER BADGE
             ===================================================================== */}
          <motion.div
            id="intro-entry-cue"
            initial={{ opacity: 0, y: 15 }}
            animate={{
              opacity: isDrawn ? 1 : 0,
              y: isDrawn ? 0 : 15,
            }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center -mt-4 sm:-mt-6 z-20"
          >
            {/* Luminous Golden Thread Line */}
            <div className="relative flex flex-col items-center">
              <div className="w-[1.5px] h-8 sm:h-12 bg-gradient-to-b from-[#F0C45B] via-[#D49A25]/70 to-transparent shadow-[0_0_12px_rgba(240,196,91,0.6)]" />
              <div className="w-1.5 h-1.5 rounded-full bg-[#F0C45B] shadow-[0_0_10px_#F0C45B] -mt-0.5" />
            </div>

            {/* Interactive "ENTER STUDIO" Button with Animated Arrow */}
            <div
              id="intro-enter-studio-btn"
              onClick={(e) => {
                e.stopPropagation();
                handleTriggerExit();
              }}
              className="group mt-3 flex items-center gap-3 px-6 py-2.5 rounded-full border border-[#D49A25]/40 bg-[#0C0C0B]/90 hover:bg-[#1C1A17] hover:border-[#F0C45B] transition-all duration-300 shadow-[0_4px_25px_rgba(0,0,0,0.6)] cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#F0C45B] animate-pulse" />
              <span className="font-['Cinzel',serif] text-xs sm:text-sm tracking-[0.3em] uppercase text-[#EAD8B7] group-hover:text-[#FFF8EC] transition-colors">
                Enter Studio
              </span>
              <motion.div
                animate={{ y: [0, 4, 0] }}
                transition={{ duration: 1.4, repeat: Infinity, ease: 'easeInOut' }}
                className="w-5 h-5 rounded-full bg-[#F0C45B]/15 flex items-center justify-center text-[#F0C45B] border border-[#F0C45B]/30 group-hover:bg-[#F0C45B] group-hover:text-[#0C0C0B] transition-all"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </motion.div>
            </div>

            {/* Subtle Keyboard / Tap hint */}
            <span className="mt-2 text-[10px] tracking-[0.2em] uppercase text-[#8E877B] font-['Montserrat',sans-serif]">
              Click anywhere or press Enter to unveil
            </span>
          </motion.div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
